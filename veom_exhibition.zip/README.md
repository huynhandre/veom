# AAD_Voxel

## Group members
Amelie Hofer, André Huynh, Robin Paule, Ferdinand Ruff 
## Description: 
We wanted to create a designtool, which allows the user to easily generate a freeform structure that consists of voxels and different filling geometries. 
The generated structure adapts to attractor points and their strength and is easily downloadable (we are still facing problems with the downloaded gltf files).

Please open the app and play around!
